from sklearn.model_selection import cross_val_score

def cross_validate(clf,X_train,y_train,cv=10):
    """
    Cross validates the model.
    Returns an array of scores.
    """
    scores = cross_val_score(clf,X_train,y_train, 
                             cv=cv)
    return scores

    