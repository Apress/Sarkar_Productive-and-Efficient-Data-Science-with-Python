from sklearn.model_selection import train_test_split

def data_split(X,y, 
               test_size=0.3,
               random_state=42):
    """
    Randomly splits in test and train sets 
    and returns them as Numpy arrays
    """
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state)
    
    return  X_train, X_test, y_train, y_test