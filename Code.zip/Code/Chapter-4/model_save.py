from joblib import dump, load

def model_save(clf,scores,threshold=0.9):
    """
    Saves a model depending on the CV scores
    """
    if scores.mean() > threshold:
        dump(clf, 'logistic_model.joblib')
        return 1
    else:
        return 0
        
    